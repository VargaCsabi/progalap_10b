#Beolvasas
celsius = float(input("Celsius:"))
#feldolgozas
fahrenheit = 9 / 5 * celsius + 32
#kiiras
print("Fahrenheit:", fahrenheit)