#beolvasas
#print("Add meg a neved: ", end="")
nev = input("add meg a neved: ")

#Kiirás
#print("Szia", nev, end="!")
print("Szia " + nev + "!")
