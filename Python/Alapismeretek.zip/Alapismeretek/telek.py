hossz = 45
szelesseg = 35
kapu = 5

kerites =2*hossz + 2*szelesseg - kapu
alapterület =hossz*szelesseg

print("a kerítés hossza:", kerites)
print("a telek alapterülete:", alapterület) 