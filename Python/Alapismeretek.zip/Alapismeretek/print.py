print("alma", "fa")
print("alma", "fa", "barack", "fa", sep="\n")
print("alma" + "fa")
print("almafa")    