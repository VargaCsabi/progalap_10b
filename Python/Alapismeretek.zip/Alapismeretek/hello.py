print("Hello World!")
print('Hello World!')
#Egy soros komment
print("Hello World!")
#kecske
"""
Bármi ami itt van,
az többsoros komment!
"""
print('Hello World!')
print("Hello\n World")
