ideiEv =2022



#Beolvasas
eletkor = input("Eletkor: ")
eletkor = float(eletkor)

#feldolgozás
kesobbi = eletkor + (2050 - ideiEv)
#Kiiras
print("jovore: ", eletkor+1)
print("2050ben: " + str(kesobbi))
#print("2050ben: ", kesobbi)